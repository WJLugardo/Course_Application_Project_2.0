package junitTests;

import static org.junit.jupiter.api.Assertions.*;

class PetOwnerTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void getName() {
    }

    @org.junit.jupiter.api.Test
    void setName() {
    }

    @org.junit.jupiter.api.Test
    void getPets() {
    }

    @org.junit.jupiter.api.Test
    void setPets() {
    }

    @org.junit.jupiter.api.Test
    void addPet() {
    }

    @org.junit.jupiter.api.Test
    void displayPets() {
    }

    @org.junit.jupiter.api.Test
    void displayDiaryEntries() {
    }

    @org.junit.jupiter.api.Test
    void testDisplayDiaryEntries() {
    }

    @org.junit.jupiter.api.Test
    void getUserType() {
    }

    @org.junit.jupiter.api.Test
    void getDiaries() {
    }

    @org.junit.jupiter.api.Test
    void testToString() {
    }
}