package interfaces;

public interface UserType {
    default String getUserType() {
        return "User";
    }
}
