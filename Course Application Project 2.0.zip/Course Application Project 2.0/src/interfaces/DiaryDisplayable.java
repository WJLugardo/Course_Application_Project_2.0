package interfaces;

import model.Pet;

import java.time.LocalDate;

public interface DiaryDisplayable {
    void displayDiaryEntries(Pet pet);

    void displayDiaryEntries(Pet pet, LocalDate date);
}